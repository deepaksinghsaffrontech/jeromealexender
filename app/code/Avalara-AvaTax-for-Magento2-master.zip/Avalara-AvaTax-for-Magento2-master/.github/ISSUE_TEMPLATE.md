Avalara has shifted how they are handling support for this extension and are no longer providing support via Github issues. For support, please contact support@avalara.com
