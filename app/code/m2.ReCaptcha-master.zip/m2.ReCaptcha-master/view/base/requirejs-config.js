/**
 * Copyright © Karliuka Vitalii(karliuka.vitalii@gmail.com)
 * See COPYING.txt for license details.
 */
var config = {
    map: {
        '*': {
            'faonni/recaptcha' : 'Faonni_ReCaptcha/js/reCaptcha'
        }
    }
};