var config = {
 map: {
        '*': {
            lazyload: 'Magebees_Lazyload/js/lazysizes.min'
        }
    }
    
};