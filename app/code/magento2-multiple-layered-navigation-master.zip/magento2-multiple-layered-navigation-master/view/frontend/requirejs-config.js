var config = {
    map: {
        '*': {
            niksNavigation: 'Niks_LayeredNavigation/js/navigation',
            niksSlider: 'Niks_LayeredNavigation/js/slider'
        }
    }
};
